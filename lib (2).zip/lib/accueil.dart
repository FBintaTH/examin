/*import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
 
class Accueil extends StatefulWidget {
  Accueil({Key? key}) : super(key: key);
  @override
  _AccueilState createState() => _AccueilState();
}
 
class _AccueilState extends State<Accueil> {
  double _progress = 0.0;
  List<Map<String, dynamic>> allCitiesWeather = [];
  List<String> cities = ['Rennes', 'Paris', 'Nantes', 'Bordeaux', 'Lyon'];
  List<String> messages = [
    'Nous téléchargeons les données...',
    'C\'est presque fini...',
    'Plus que quelques secondes avant d\'avoir le résultat...'
  ];
  int messageIndex = 0;
  Timer? timer;
  bool _downloadFinished = false;
 
  void initState() {
    super.initState();
    _updateProgress();
    startTimer();
  }
 
  void _updateProgress() async {
    for (var i = 0; i < 60; i++) {
      await Future.delayed(Duration(seconds: 1));
      setState(() {
        _progress = (i + 1) * (100 / 60);
      });
    }
    setState(() {
      _downloadFinished = true;
    });
  }
 
  Future<Map<String, dynamic>> fetchWeather(String city) async {
    String apiKey = '79b208e2e2e510b9ba4de0155a534fc5';
    final response = await http.get(Uri.parse(
        'https://api.openweathermap.org/data/2.5/weather?q=$city&appid=$apiKey&units=metric'));
    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception('Failed to fetch weather data for $city');
    }
  }
 
  void printWeatherDataForOneCity(String cityName) async {
    final weatherData = await fetchWeather(cityName);
    setState(() {
      allCitiesWeather.add(weatherData);
    });
    print('$cityName: $weatherData');
    print('allCitiesWeather: $allCitiesWeather');
  }
 
  void startTimer() {
    int x = 0;
    timer = Timer.periodic(Duration(seconds: 6), (timer) {
      if (x == 4) timer.cancel();
      print('x:$x');
      printWeatherDataForOneCity(cities[x]);
      x = x + 1;
      setState(() {
        messageIndex = (messageIndex + 1) % messages.length;
      });
    });
  }
 
  void _restartDownload() {
    setState(() {
      _progress = 0.0;
      allCitiesWeather.clear();
      _downloadFinished = false;
    });
    _updateProgress();
    startTimer();
  }
 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Progression'),
      ),
      body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              'Téléchargement en cours...',
              style: TextStyle(fontSize: 24),
            ),
            SizedBox(height: 50),
            Text(
              messages[messageIndex],
              style: TextStyle(fontSize: 24),
            ),
            SizedBox(
              height: 20,
            ),
            LinearProgressIndicator(
              value: _progress / 100,
              backgroundColor: Colors.grey[300],
              valueColor: AlwaysStoppedAnimation<Color>(
                  Color.fromARGB(255, 222, 63, 119)),
            ),
            SizedBox(height: 20),
            Text(
              '${_progress.round()}%',
              style: TextStyle(fontSize: 24),
            ),
            SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                  itemCount: allCitiesWeather.length,
                  itemBuilder: (BuildContext context, int index) {
                    final cityName = allCitiesWeather[index]['name'];
                    final temp = allCitiesWeather[index]['main']['temp'];
                    final iconCode =
                        allCitiesWeather[index]['weather'][0]['icon'];
                    return ListTile(
                      title: Text('$cityName: $temp°C'),
                      subtitle: Row(
                        children: [
                          Image.network(
                            'http://openweathermap.org/img/w/$iconCode.png',
                            width: 50,
                            height: 50,
                          ),
                          SizedBox(width: 10),
                        ],
                      ),
                    );
                  }),
            ),
            if (_downloadFinished)
              TextButton(
                onPressed: () {
                  // Réinitialiser les variables et relancer le téléchargement
                  setState(() {
                    _progress = 0.0;
                    allCitiesWeather = [];
                    _downloadFinished = false;
                  });
                  startTimer();
                  _updateProgress();
                },
                child: Text(
                  'Recommencer',
                  style: TextStyle(fontSize: 18),
                ),
              )
          ]),
    );
  }
}

*/
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:percent_indicator/percent_indicator.dart';
import 'package:http/http.dart' as http;

const cities = ["Rennes", "Paris", "Nantes", "Bordeaux", "Lyon"];
const apiKey = '79b208e2e2e510b9ba4de0155a534fc5';

class Accueil extends StatefulWidget {
  const Accueil({Key? key}) : super(key: key);

  @override
  State<Accueil> createState() => _AccueilState();
}

class _AccueilState extends State<Accueil>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  double _progressValue = 0.0;
  IconData _emoji = Icons.sentiment_neutral;

  final List<String> _weatherData = [""];

  Timer? _timer;
  final List<String> _loadingMessages = [    "Nous téléchargeons les données...",    "C'est presque fini...",    "Plus que quelques secondes avant d'avoir le résultat final..."  ];

  int _loadingMessageIndex = 0;

  Timer? _loadingTimer;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 60),
    );
    _animationController.addListener(() {
      setState(() {
        _progressValue = _animationController.value;
        if (_progressValue < 0.33) {
          _emoji = Icons.sentiment_dissatisfied;
        } else if (_progressValue < 0.66) {
          _emoji = Icons.sentiment_neutral;
        } else {
          _emoji = Icons.sentiment_satisfied;
        }
      });
    });
    _animationController.forward();
    _timer = Timer.periodic(const Duration(seconds: 10), (timer) {
      _fetchWeatherData();
    });
    _loadingTimer = Timer.periodic(const Duration(seconds: 6), (timer) {
      setState(() {
        _loadingMessageIndex = (_loadingMessageIndex + 1) % _loadingMessages.length;
       /* if (timer==60) {
           child: Text(
                  'FIN',
                  style: TextStyle(fontSize: 18),
                );
          
        }*/
      });
    });
  }

  @override
  void dispose() {
    _animationController.dispose();
    _timer?.cancel();
    _loadingTimer?.cancel();
    super.dispose();
  }

  int _cityIndex = 0;

  void _fetchWeatherData() async {
    final city = cities[_cityIndex];
    final url = "https://api.openweathermap.org/data/2.5/weather?q=$city&appid=$apiKey&units=metric&lang=fr&exclude=minutely,hourly&appid=$apiKey";
    final response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      final weatherDescription = data["weather"][0]["description"];
      final temperature = data["main"]["temp"];
      final precipitation = data["rain"] != null ? data["rain"]["1h"] : "N/A";
      final humidity = data["main"]["humidity"];
      final windSpeed = data["wind"]["speed"];
      final weatherIcon = data["weather"][0]["icon"];
      final weatherCode = weatherIcon.substring(0, 2);
      String icon;
      switch (weatherCode) {
        case "01":
          icon = "☀️";
          break;
        case "02":
          icon = "⛅️";
          break;
        case "03":
        case "04":
          icon = "☁️";
          break;
        case "09":
        case "10":
        case "11":
          icon = "🌧";
          break;
        case "13":
          icon = "❄️";
          break;
        default:
          icon = "☀️";
      }
      setState(() {
        _weatherData.add("$city: $weatherDescription $icon, $temperature°C,Précipitations: $precipitation mm, Humidité: $humidity%, Vitesse du vent: $windSpeed m/s");
      });
    } else {
      print("Failed to fetch weather data for $city");
    }

    _cityIndex++;
    if (_cityIndex >= cities.length) {
      _cityIndex = 6;
       
      
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(136, 0, 0, 0),
      appBar: AppBar(
        title: const Text('World Weather'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            const Text(
              'Discussion avec votre banquier, pas commode. ',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Color.fromARGB(255, 19, 120, 228),
                fontSize: 20,
              ),
            ),
            const SizedBox(height: 20),
            Text(
              _loadingMessages[_loadingMessageIndex],
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 20,
              ),
            ),
            const SizedBox(height: 20),
           
            const SizedBox(height: 40),
            Text(
              'Progression : ${(100 * _progressValue).toStringAsFixed(0)}%',
              style: const TextStyle(fontSize: 18.0,color: Colors.white,fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 15),
            LinearPercentIndicator(
              alignment: MainAxisAlignment.center,
              width: 350,
              lineHeight: 20,
              percent: _progressValue,
                barRadius: const Radius.circular(20),
              backgroundColor: Colors.white.withOpacity(0.9),
	progressColor: Color.fromARGB(255, 25, 123, 228),
            ),
            const SizedBox(height: 40),
            Expanded(
              child: ListView.builder(
                itemCount: _weatherData.length,
                itemBuilder: (context, index) {
                  return Container(
                    padding: const EdgeInsets.only(top: 10),
                    decoration: BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                          color: Colors.white.withOpacity(0.9),
                          blurRadius: 4,
                          offset: const Offset(0, 5),
                        ),
                      ],
                    ),
                    child: ListTile(
                      title: Text(
                        _weatherData[index],
                        style: const TextStyle(
                          color: Color.fromARGB(255, 240, 210, 17),
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          fontStyle: FontStyle.italic,
                          fontFamily: 'Arial',
                        ),
                      ),
                    ),
                  );
                },

              ),
            ),
          ],
        ),
      ),
    );
  }
}

 