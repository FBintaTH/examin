import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_dotenv/flutter_dotenv.dart';

class SecondPage extends StatefulWidget {
  @override
  _SecondPageState createState() => _SecondPageState();
}

class _SecondPageState extends State<SecondPage> {
  double _progress = 0.0;

  @override
  void initState() {
    super.initState();
    _updateProgress();
    startTimer();
  }

  void _updateProgress() async {
    for (var i = 0; i < 60; i++) {
      await Future.delayed(Duration(seconds: 1));
      setState(() {
        _progress = (i + 1) * (100 / 60);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Progression'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            'Téléchargement en cours...',
            style: TextStyle(fontSize: 24),
          ),
          SizedBox(height: 20),
          LinearProgressIndicator(
            value: _progress / 100,
            backgroundColor: Colors.grey[300],
            valueColor: AlwaysStoppedAnimation<Color>(Colors.blue),
          ),
          SizedBox(height: 20),
          Text(
            '${_progress.round()}%',
            style: TextStyle(fontSize: 24),
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => SecondPage()),
              );
            },
            child: Text('Afficher les données météo'),
          )
        ],
      ),
    );
  }
}


// Liste de villes à interroger
List<String> cities = ['Rennes', 'Paris', 'Nantes', 'Bordeaux', 'Lyon'];

// Fonction pour appeler l'API météo pour une ville donnée
Future<Map<String, dynamic>> fetchWeather(String city) async {
  final apiKey = DotEnv().env['0b5b5cb255feb5ec8d8c9189964ac17b'];
  final response = await http.get(Uri.parse(
      'https://api.openweathermap.org/data/2.5/weather?q=$city&appid=$apiKey'));
  if (response.statusCode == 200) {
    return json.decode(response.body);
  } else {
    throw Exception('Failed to fetch weather data for $city');
  }
}

// Fonction pour afficher les données de météo pour chaque ville
void printWeatherData() async {
  for (var i = 0; i < cities.length; i++) {
    final weatherData = await fetchWeather(cities[i]);
    print('$cities[i]: $weatherData');
  }
}

// Fonction pour lancer le timer
void startTimer() {
  Timer.periodic(Duration(seconds: 10), (timer) {
    printWeatherData();
  });
}
